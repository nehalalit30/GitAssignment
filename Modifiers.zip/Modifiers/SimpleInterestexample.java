package Modifiers;

public class SimpleInterestexample {
	public double calculateSI(int p, int r, int t)
	{
		double si = p*r*t/100;
		return si;	
	}

	public static void main(String[] args) 
	{
		SimpleInterestexample s = new SimpleInterestexample();
		double res= s.calculateSI(65, 30, 5);
		System.out.println("The Simple interest is: "+ res);
		double sum = res+30; //after assigning a variable
		System.out.println("The amount is: "+ sum);
		System.out.println("The amount is: "+(res+30));//without assigning variable
	}
}