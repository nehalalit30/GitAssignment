package Modifiers;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;

public class collectionDemo {

	
		public static void main(String[] args) {
			LinkedHashSet L1 = new LinkedHashSet();
			L1.add(10);         
	        L1.add(5);          
	        L1.add(5.5f);        
	        L1.add(7.7f);        
	        L1.add('A');         
	        L1.add('B');        
	        L1.add(true);
	        System.out.println("L1: " + L1);
	        
	        L1.add(30);          
	        L1.add(8.8f);        

	        L1.remove(7.7f);
	        System.out.println("L1: " + L1);
	        boolean hasFive = L1.contains(5);
	        boolean hasstring= L1.contains("nfse");
	        System.out.println("L1 has 5: " + hasFive);
	        System.out.println("string present or not: "+ hasstring);
	        
	        LinkedHashSet L2 = new LinkedHashSet();
	        Scanner sc= new Scanner(System.in);
	        for(int i=0;i<10;i++) {
	        	System.out.println("Add element "+ i);
	        	L2.add(sc.nextInt());
	        }
	        System.out.println("L2: " + L2);
	        
	        L1.clear();
	        System.out.println("L1 after clear: "+ L1);		
}
}
