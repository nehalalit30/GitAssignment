package Modifiers;
import java.util.LinkedHashMap;
import java.util.Map;

public class linkedHashmap {
	public static void main(String[] args) {
		 LinkedHashMap<Integer, String> m = new LinkedHashMap<>();
		 m.put(1, "Australia");
		 m.put(10, "india");
		 m.put(20, "africa");
		 m.put(30, "dubai");
		 m.put(40, "paris");
		 m.put(50, "new york");
		 m.put(60, "china");
		 m.put(70, "pakistan");
		 m.put(80, "singapore");
		 m.put(90, "london");
		 
		 System.out.println("Map Keys: " + m.keySet());
		 System.out.println("Map values: " + m.values());
		 
		 boolean hasIndia = m.containsValue("india");
	        System.out.println("Does the map contain 'India'? " + hasIndia);
	        
	        boolean hasKey45 = m.containsKey(45);
	        System.out.println("Does the map contain key 45? " + hasKey45);
	        
	       m.remove(50);
	        System.out.println("Map after removing : " + m);
		 
		 
		 
	}
	

}
