package Modifiers;
class Product{
	int id= 78;
	String name= "Amul";
	void display() {
		System.out.println("ID:"+ id+" Name: "+ name);
	}
}
class A extends Product{
	int count= 50;
	String category="Butter";
	
	void displayall() {
		display();
		System.out.println("count:"+ count+ " category: "+ category);
		
	}
}
class B extends Product{
	int count= 90;
	String category="Milk";
	
	void displayall() {
		display();
		System.out.println("count:"+ count+ " category: "+ category);
		
	}
}
class C extends Product{
	int count= 56;
	String category="choco";
	
	void displayall() {
		display();
		System.out.println("count:"+ count+ " category: "+ category);
		
	}
}
class Suba extends A{
	int price=30;
	 void calculatetotal() {
		 int tp= count*price;
		 displayall();
		 System.out.println("total price: "+ tp);
	 }	
}
class Subb extends B{
	int price=10;
	 void calculatetotal() {
		 int tp= count*price;
		 displayall();
		 System.out.println("total price: "+ tp);
	 }	
}
public class InheritanceExample {
	public static void main(String[] args) {
		Suba obja= new Suba();
		obja.calculatetotal();
		
		Subb objb= new Subb();
		objb.calculatetotal();
		
		C objc= new C();
		objc.displayall();
	}

}
