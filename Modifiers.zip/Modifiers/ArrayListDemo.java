package Modifiers;

import java.util.*;

public class ArrayListDemo {

	 
public static void main(String[] args) {
			ArrayList<String> L1=new ArrayList<String>();
			L1.add("apple");
			L1.add("banana");
			L1.add("mango");
			L1.add("grapes");
			L1.add("orange");
			L1.add("litchi");
			L1.add("chennai");
			L1.add("chandigarh");
			L1.add("dancing");
			L1.add("sleeping");
			System.out.println("arraylist is: "+ L1);
			L1.remove("dancing");
			System.out.println("arraylist after removing hobby: "+ L1);
			boolean check= L1.contains("cricket");
			System.out.println("string present?: "+ check);
			L1.remove("chennai");
			L1.remove("litchi");
			System.out.println("arraylist is: "+ L1);
			System.out.println(L1.get(3));
			System.out.println(L1.get(5));
			int ind= L1.indexOf("sleeping");
			L1.set(ind,"singing");
			System.out.println("arraylist is: "+ L1);
		}
	}




;
