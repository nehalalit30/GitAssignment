package Modifiers;
import java.util.LinkedList;
import java.util.Iterator;

public class LinkList {
	 public static void main(String[] args) {
		 LinkedList<String> l1 = new LinkedList<>();
		 l1.add("May");
	     l1.add("June");
	     l1.add("July");
	     l1.add("August");
	     l1.add("April");
	     l1.add("November");
	     

	     l1.addLast("December");
	     l1.addFirst("January");
	     
	     l1.add(1, "March");
	     l1.add(2, "February");
	     
	     l1.add(9, "September");
	     l1.add(10, "October");
	     
	     System.out.println("LinkedList in not proper order: " + l1);
	    l1.remove(2);
	    l1.add(1,"February");
	    l1.remove(7);
	    l1.add(3,"april");
	    l1.remove(8);
	    l1.add(10,"November");
	     System.out.println("LinkedList in  proper order: " + l1);
	     System.out.println("Even months: ");
	        for (int i = 1; i <= l1.size(); i++) {
	            if (i % 2 == 0) {
	                System.out.println(l1.get(i - 1));
	            }
	        }

	        System.out.println("Odd months: ");
	        for (int i = 1; i <= l1.size(); i++) {
	            if (i % 2 != 0) {
	                System.out.println(l1.get(i - 1));
	            }
	        }
	        

	        System.out.println("All months using iterator: ");
	        Iterator<String> it = l1.iterator();
	        while (it.hasNext()) {
	            System.out.println(it.next());
	        }
	        

	        System.out.println("First month: " + l1.getFirst() + ", Last month: " + l1.getLast());
	        l1.remove("September");
	       System.out.println("after removing birthday month: "+ l1);
	       
	       

	        boolean hasWinterMonth = l1.contains("December") || l1.contains("January") || l1.contains("February");
	        System.out.println("Does the LinkedList contain any winter month? " + hasWinterMonth);
	        
	        System.out.println("First month using peek: " + l1.peekFirst());
	        System.out.println("Last month using peek: " + l1.peekLast());
	        
	        System.out.println("First month removed using poll: " + l1.pollFirst());
	        System.out.println("Last month removed using poll: " +l1.pollLast());
	        
	        System.out.println("Final LinkedList: " + l1);
		 
	 }
}
