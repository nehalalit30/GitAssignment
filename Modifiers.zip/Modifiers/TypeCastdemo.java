package Modifiers;

public class TypeCastdemo {
	public int calculate(int d1, int d2) {
		int area= (d1*d2)/2;
		return area;
	}
	int calculate(int r) {
	 int area= (int)3.14f * r * r;
		return area;
	}
	
	float calculate(float l, float b) {
		float area= l* b;
		return (int)area;
	}
	
	long calculate(long s) {
		long area= s*s;
		return (int)area;
	}
	

	public static void main(String[] args) {
		TypeCastdemo tc= new TypeCastdemo();
		System.out.println("Area of rhombus is "+ tc.calculate(6,4));
		System.out.println("Area of circle is "+ tc.calculate(7));
		System.out.println("Area of rectangle is "+ tc.calculate(5,3));
		System.out.println("Area of square is "+ tc.calculate(68767567L));
		
		

	}

}
