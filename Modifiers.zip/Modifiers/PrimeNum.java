package Modifiers;
import java.util.Scanner;

public class PrimeNum {
	public void prime(int a)
	{
		for(int i=2;i<=a/2;i++)
		{
			if(a%i==0) 
			{
				System.out.println(a+" is not prime");
				return;
			}
			
		}
		System.out.println(a+" is prime");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter a number: ");
		Scanner sc= new Scanner(System.in);
		int n= sc.nextInt();

		PrimeNum p= new PrimeNum();	
		p.prime(n);
	}
}
	



