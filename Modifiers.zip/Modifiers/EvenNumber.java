package Modifiers;
import java.util.Scanner;

public class EvenNumber {
	void checkeven(int n) {
		if(n%2==0) {
			System.out.println(n+" is even");
		}
		else {
			System.out.println(n+" is odd");
		}
	}
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter number:");
		int n= scanner.nextInt();
		
		EvenNumber e= new EvenNumber();
		e.checkeven(n);		
		
	}

}
  