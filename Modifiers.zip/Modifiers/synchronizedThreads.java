package Modifiers;
class FactorialCalculator implements Runnable {
    private int number;

    public FactorialCalculator(int number) {
        this.number = number;
    }

    public void run() {
        synchronized (this) {
            long result = factorial(number);
            System.out.println(Thread.currentThread().getName() + " (Factorial of " + number + "): " + result);
        }
    }

    private long factorial(int n) {
        if (n == 0) return 1;
        return n * factorial(n - 1);
    }
}

class SumCalculator implements Runnable {
    private int a, b;

    public SumCalculator(int a, int b) {
        this.a = a;
        this.b = b;
    }

    public void run() {
        synchronized (this) {
            int sum = a + b;
            System.out.println(Thread.currentThread().getName() + " (Sum of " + a + " and " + b + "): " + sum);
        }
    }
}

public class synchronizedThreads {
    public static void main(String[] args) {
       
        Thread t1 = new Thread(new FactorialCalculator(4), "t1");
        Thread t2 = new Thread(new FactorialCalculator(6), "t2");

   
        Thread t3 = new Thread(new SumCalculator(4, 5), "t3");
        Thread t4 = new Thread(new SumCalculator(20, 10), "t4");

        t1.start();
        t2.start();
        t3.start();
        t4.start();

        try {
            t2.join();
            t4.join();
            t1.join();
            t3.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
