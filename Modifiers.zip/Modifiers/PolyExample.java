package Modifiers;

abstract class MNC {
 public MNC() {
     System.out.println("MNC Constructor");
 }

 abstract void leaves(); 
 abstract void holidays(); 

 void normalMethod() {
     System.out.println("Normal method in MNC");
 }
}

abstract class Mindsprint extends MNC {

 abstract void leaves(); 

 void holidays() {
     System.out.println("Holidays method in Mindsprint");
 }
}

class Hello extends Mindsprint {
 void leaves() {
     System.out.println("Leaves method in Hello");
 }

 void holidays() {
     System.out.println("Holidays method in Hello");
 }

 void newMethod() {
     System.out.println("New method in Hello");
 }
}

public class PolyExample {
 public static void main(String[] args) {
     MNC obj = new Hello(); 
     obj.leaves();
     obj.holidays();
     obj.normalMethod();

     ((Hello) obj).newMethod(); 
 }
}


