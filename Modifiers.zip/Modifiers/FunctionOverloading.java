package Modifiers;

public class FunctionOverloading {
	public void area(int a, int b) {
		System.out.println("Area is: "+ (a+b));
	}
	
	float area(float radius) {
		float res= 3.14f*radius*radius;
		return res;
	}
	public void area(int y, long x,long z) {
		System.out.println("sum is: "+ (y+x+z));
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FunctionOverloading f= new FunctionOverloading();
		int y= (int)f.area(30.5f);
		System.out.println("circle area:"+ y);
		f.area(5,8);
		f.area(4,8,2);
		
		

	}

}
